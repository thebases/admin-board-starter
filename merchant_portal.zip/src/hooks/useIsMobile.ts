// src/hooks/useIsMobile.ts
import { useEffect, useState } from 'react'

export function useIsMobile(breakpoint: string = '(max-width: 768px)') {
  const [isMobile, setIsMobile] = useState(false)

  useEffect(() => {
    const mediaQuery = window.matchMedia(breakpoint)

    const handleChange = () => setIsMobile(mediaQuery.matches)
    handleChange() // set initial value

    mediaQuery.addEventListener('change', handleChange)
    return () => mediaQuery.removeEventListener('change', handleChange)
  }, [breakpoint])

  return isMobile
}

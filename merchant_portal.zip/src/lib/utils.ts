import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'
import { BANKLIST } from '@/lib/enum'
import type { MqttContextType } from '@/providers/mqtt/MqttProvider'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}
export async function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

export function getBankByBinCode(binCode: string) {
  return BANKLIST.find((bank) => bank.bin === binCode)
}

export function getBankNameByBinCode(binCode: string) {
  return BANKLIST.find((bank) => bank.bin === binCode)?.name
}

export function generateRandom16DigitNumber(): string {
  return Array.from({ length: 16 }, () => Math.floor(Math.random() * 10)).join(
    '',
  )
}

export function getCurrentTimeStamp(): number {
  const timestamp = Date.now() // Unix timestamp in milliseconds
  console.log('Timestamp:', timestamp)
  return timestamp
}
export function formatDate(date: Date): string {
  const options: Intl.DateTimeFormatOptions = {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  }
  return new Intl.DateTimeFormat('en-US', options).format(date)
}
export function formatDateToISO(date: Date): string {
  return date.toISOString()
}
export function formatDateToVietnamese(date: Date): string {
  const options: Intl.DateTimeFormatOptions = {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  }
  return new Intl.DateTimeFormat('vi-VN', options).format(date)
}
export function formatDateToVietnameseISO(date: Date): string {
  return date.toLocaleDateString('vi-VN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  })
}
export function formatDateToVietnameseWithTime(date: Date): string {
  return date.toLocaleString('vi-VN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  })
}
export function formatDateToVietnameseWithTimeISO(date: Date): string {
  return date.toLocaleString('vi-VN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  })
}
export function formatDateToVietnameseWithTimeAndZone(date: Date): string {
  return date.toLocaleString('vi-VN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    timeZoneName: 'short',
  })
}
export function getCurrentDate(): string {
  const now = new Date()

  const yyyy = now.getFullYear()
  const mm = String(now.getMonth() + 1).padStart(2, '0') // Months are zero-based
  const dd = String(now.getDate()).padStart(2, '0')
  const hh = String(now.getHours()).padStart(2, '0')
  const min = String(now.getMinutes()).padStart(2, '0')
  const ss = String(now.getSeconds()).padStart(2, '0')

  return `${yyyy}${mm}${dd}${hh}${min}${ss}`
}

function publishToDevice(
  mqtt: MqttContextType,
  topic: string,
  payload: string,
): number {
  if (mqtt.connected && topic != '') {
    mqtt.publish(topic, payload)
    console.debug('MQTT client reset successfully.')
    return 0
  } else {
    console.debug('No MQTT client to reset.')
    return 1
  }
}

export function deviceGenQR(
  mqtt: MqttContextType,
  topic: string,
  money: string,
  orderId: string,
) {
  const payload = {
    money: money,
    request_id: generateRandom16DigitNumber(),
    order_sn: orderId,
    datetime: getCurrentDate(),
    ctime: getCurrentTimeStamp(),
  }
  mqtt.publish(topic, JSON.stringify(payload))
}

export function resetMerchant(mqtt: MqttContextType, topic: string): number {
  const payload = {
    broadcast_type: 1,
    messageType: 'resetMerchant',
    request_id: generateRandom16DigitNumber(),
    datetime: getCurrentDate(),
    ctime: getCurrentTimeStamp(),
  }
  return publishToDevice(mqtt, topic, JSON.stringify(payload))
}

export function deviceSetMerchant(
  mqtt: MqttContextType,
  topic: string,
  storeName: string,
  bankAccount: string,
  bankBincode: string,
): number {
  const payload = {
    broadcast_type: 1,
    messageType: 'updateMerchant',
    payload: {
      merchantName: storeName,
      merchantId: bankAccount,
      binCode: bankBincode,
    },
    request_id: generateRandom16DigitNumber(),
    datetime: getCurrentDate(),
    ctime: getCurrentTimeStamp(),
  }
  return publishToDevice(mqtt, topic, JSON.stringify(payload))
}

export function deviceCancelQR(mqtt: MqttContextType, topic: string): number {
  const payload = {
    broadcast_type: 1,
    messageType: 'closeQr',
    request_id: generateRandom16DigitNumber(),
    datetime: getCurrentDate(),
    ctime: getCurrentTimeStamp(),
  }
  return publishToDevice(mqtt, topic, JSON.stringify(payload))
}

import * as React from 'react'

import { getBankByBinCode, sleep } from '@/lib/utils'

export interface AuthContext {
  isAuthenticated: boolean
  user: string | null
  bankAccount: string | null
  bankBincode: string | null
  bankName: string | null
  storeName: string | null
  defaultDevice: string | null
  setDevice: (serial: string | null) => Promise<void>
  setAuthData: (
    bankAcc?: string | undefined,
    bankBin?: string | undefined,
    sName?: string | undefined,
  ) => Promise<void>
  login: (
    bankAccount?: string,
    bankBincode?: string,
    storeName?: string,
  ) => Promise<void>
  logout: () => Promise<void>
}

const AuthContext = React.createContext<AuthContext | null>(null)

const key = 'auth.user'
const keyBankAccount = 'auth.bankAcoount'
const keyBankBincode = 'auth.bankBincode'
const keyBankName = 'auth.bankName'
const keyStoreName = 'auth.storeName'
const keyDefaultDevice = 'auth.defaultDevice'

// Getter - Setter

function getStoredUser() {
  return localStorage.getItem(key)
}

function setStoredUser(user: string | null) {
  if (user) {
    localStorage.setItem(key, user)
  } else {
    localStorage.removeItem(key)
  }
}

function getStorebyKey(keyStore: string) {
  return localStorage.getItem(keyStore)
}

function setStoredByKey(keyStore: string, data: string | null) {
  if (data) {
    localStorage.setItem(keyStore, data)
  } else {
    localStorage.removeItem(keyStore)
  }
}

//  Provider

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = React.useState<string | null>(getStoredUser())
  const [bankAccount, setBankAccount] = React.useState<string | null>(
    getStorebyKey(keyBankAccount),
  )
  const [bankBincode, setBankBincode] = React.useState<string | null>(
    getStorebyKey(keyBankBincode),
  )
  const [bankName, setBankName] = React.useState<string | null>(
    getStorebyKey(keyBankName),
  )
  const [storeName, setStoreName] = React.useState<string | null>(
    getStorebyKey(keyStoreName),
  )
  const [defaultDevice, setDefaultDevice] = React.useState<string | null>(
    getStorebyKey(keyDefaultDevice),
  )
  const isAuthenticated = !!user

  const logout = React.useCallback(async () => {
    await sleep(250)

    setStoredUser(null)
    setStoredByKey(keyBankAccount, null)
    setStoredByKey(keyBankBincode, null)
    setStoredByKey(keyStoreName, null)
    setStoredByKey(keyBankName, null)
    setUser(null)
    setBankAccount(null)
    setBankBincode(null)
    setStoreName(null)
    setBankName(null)
  }, [])

  const login = React.useCallback(
    async (bankAccount?: string, bankBincode?: string, storeName?: string) => {
      await sleep(500)
      const username = 'hardcode user' // Call api to get user later
      setStoredUser(username || null)
      setStoredByKey(keyBankAccount, bankAccount || null)
      setStoredByKey(keyBankBincode, bankBincode || null)
      setStoredByKey(keyStoreName, storeName || null)
      setStoredByKey(
        keyBankName,
        getBankByBinCode(bankBincode || '')?.name || null,
      )
      setUser(username || null)
      setBankAccount(bankAccount || null)
      setBankBincode(bankBincode || null)
      setStoreName(storeName || null)
      setBankName(getBankByBinCode(bankBincode || '')?.name || null)
    },
    [],
  )

  const setDevice = React.useCallback(async (serial: string | null) => {
    setDefaultDevice(serial)
    setStoredByKey(keyDefaultDevice, serial)
  }, [])

  const setAuthData = React.useCallback(
    async (bankAcc?: string, bankBin?: string, sName?: string) => {
      if (bankAcc) {
        setBankAccount(bankAcc)
        setStoredByKey(keyBankAccount, bankAcc || null)
      }
      if (bankBin) {
        setBankBincode(bankBin)
        setStoredByKey(keyBankBincode, bankBin || null)
      }
      if (sName) {
        setStoreName(sName)
        setStoredByKey(keyStoreName, sName || null)
      }
    },
    [],
  )

  React.useEffect(() => {
    setUser(getStoredUser())
  }, [])

  return (
    <AuthContext.Provider
      value={{
        isAuthenticated,
        user,
        bankAccount,
        bankBincode,
        bankName,
        storeName,
        defaultDevice,
        setDevice,
        setAuthData,
        login,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = React.useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

import { createFileRoute, Link, useLocation } from '@tanstack/react-router'
import { Outlet, redirect } from '@tanstack/react-router'
import { BarChart, Home, TabletSmartphone, User } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useEffect } from 'react'
import { addOrUpdateTopic } from '@/providers/mqtt/GlobalMqttDialog'
import { useAuth } from '@/providers/auth/auth'

export const Route = createFileRoute('/_auth')({
  beforeLoad: ({ context, location }) => {
    if (!context.auth.isAuthenticated) {
      throw redirect({
        to: '/login',
        search: {
          redirect: location.href,
        },
      })
    }
  },
  component: AuthLayout,
})

function AuthLayout() {
  const location = useLocation()
  const auth = useAuth()
  useEffect(() => {
    addOrUpdateTopic(`/base/${auth.bankAccount}/update`, {
      path: `/base/${auth.bankAccount}/update`,
      title: 'Thông báo',
      description: 'Thông báo từ hệ thống',
    })
  }, [])

  const isActive = (path: string) => location.pathname.startsWith(path)

  return (
    <div
      className="w-full min-w-[380px] flex flex-col items-center justify-between items-center bg-white"
      style={{ height: '100vh' }}
    >
      <div className="w-full flex flex-col justify-between items-center overflow-y-auto flex-1">
        <Outlet />
      </div>

      {/* Bottom Nav */}
      <div
        className={cn(
          'w-full  border-t flex justify-around py-2 text-sm text-gray-600',
          isActive('/qrpay') ? 'hidden' : 'h-[64px]',
        )}
      >
        <Link
          to="/home"
          className={`flex flex-col flex-1 items-center ${isActive('/home') ? 'font-bold' : 'text-gray-300'}`}
        >
          <Home className="h-5 w-5" />
          <span>Thao tác</span>
        </Link>
        <Link
          to="/transactions"
          className={`flex flex-col flex-1 items-center ${isActive('/transactions') ? 'font-bold' : 'text-gray-300'}`}
        >
          <BarChart className="h-5 w-5" />
          <span>Giao dịch</span>
        </Link>
        <Link
          to="/device"
          className={`flex flex-col flex-1 items-center ${isActive('/device') ? 'font-bold' : 'text-gray-300'}`}
        >
          <TabletSmartphone className="h-5 w-5" />
          <span>Thiết bị</span>
        </Link>
        <Link
          to="/account"
          className={cn(
            `flex flex-col flex-1 items-center ${isActive('/account') ? 'font-bold' : 'text-gray-300'}`,
          )}
        >
          <User className="h-5 w-5" />
          <span>Tài khoản</span>
        </Link>
        {/* <Drawer open={open} onOpenChange={setOpen}>
          <DrawerTrigger asChild className="p-0 m-0 ">
            <Button
              variant="ghost"
              className={`flex flex-col  w-[96px] p-0 items-center }`}
            >
              <MoreHorizontal className="h-5 w-5" />
              <span>Tác vụ</span>
            </Button>
          </DrawerTrigger>

          <DrawerContent className="p-4 pb-8">
            <h2 className="text-lg font-semibold mb-4">Tác vụ</h2>
            <div className="flex flex-col justify-center space-y-2">
              <Link
                to="/account"
                className="w-full text-center py-2 border-b"
                onClick={() => setOpen(false)}
              >
                Cập nhật thông tin
              </Link>
              <Button
                variant={'ghost'}
                onClick={handleLogout}
                className="w-full text-left py-2 border-b text-red-600"
              >
                Đăng xuất
              </Button>
            </div>
          </DrawerContent>
        </Drawer> */}
      </div>
    </div>
  )
}

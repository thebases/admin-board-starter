import { createFileRoute } from '@tanstack/react-router'
import * as React from 'react'
import { redirect, useRouter, useRouterState } from '@tanstack/react-router'
import { z } from 'zod'

import { useAuth } from '../providers/auth/auth'
import { sleep } from '@/lib/utils'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Input } from '@/components/ui/input'
// import { Globe, Moon } from 'lucide-react'
import BankSelect from '@/components/base-ui/bank-select'
import { useIsMobile } from '@/hooks/useIsMobile'

// eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
const fallback = '/home' as const

export const Route = createFileRoute('/login')({
  validateSearch: z.object({
    redirect: z.string().optional().catch(''),
  }),
  beforeLoad: ({ context, search }) => {
    if (context.auth.isAuthenticated) {
      throw redirect({ to: search.redirect || fallback })
    }
  },
  component: LoginComponent,
})

function LoginComponent() {
  const auth = useAuth()
  const router = useRouter()
  const isMobile = useIsMobile()
  const isLoading = useRouterState({ select: (s) => s.isLoading })
  const navigate = Route.useNavigate()
  const [isSubmitting, setIsSubmitting] = React.useState(false)
  const [account, setAccount] = React.useState('')
  const [bank, setBank] = React.useState('970422')

  const search = Route.useSearch()

  const onFormSubmit = async (evt: React.FormEvent<HTMLFormElement>) => {
    if (!isMobile) {
      alert(
        'Hiện ứng dụng chỉ hỗ trợ phiên bản Mobile, vui lòng sử dụng Mobile để truy cập. \n Xin chân thanh xin lỗi về sự bất tiện nay.',
      )
      return
    }
    console.log('Form submitted with:', { account, bank })
    setIsSubmitting(true)
    console.log('Submitting form...')
    try {
      evt.preventDefault()
      await auth.login(account, bank, 'Hardcode Name')

      await router.invalidate()

      // This is just a hack being used to wait for the auth state to update
      // in a real app, you'd want to use a more robust solution
      await sleep(1)
      console.log('Star navigate with:', search.redirect || fallback)
      await navigate({ to: search.redirect || fallback })
    } catch (error) {
      console.error('Error logging in: ', error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const isLoggingIn = isLoading || isSubmitting

  return (
    <div className="w-full min-h-screen flex flex-col md:flex-row md:gap-2 items-center justify-center bg-white p-0">
      <div className="hidden md:flex md:flex-col md:flex-1 md:min-h-screen md:bg-gray-100 ">
        Hello
      </div>
      <div className="md:p-4">
        <Card className=" max-w-sm shadow-xl border-none">
          <CardContent className="py-6">
            <h1 className="text-2xl font-bold text-center mb-2">Đăng nhập</h1>
            <p className="text-center text-sm text-gray-600 mb-6">
              Trang tạo mã QR dành cho cửa hàng
            </p>
            {isLoggingIn && (
              <p className="text-center text-sm text-gray-500 mb-4">
                Đang đăng nhập, vui lòng đợi...
              </p>
            )}

            <form className="mt-4 max-w-lg" onSubmit={onFormSubmit}>
              <fieldset disabled={isLoggingIn} className="w-full grid gap-6">
                <div className="grid gap-2 items-center min-w-[300px]">
                  <div className="space-y-2">
                    <Label htmlFor="account">Số tài khoản</Label>
                    <Input
                      id="account"
                      value={account}
                      onChange={(e) => setAccount(e.target.value)}
                      placeholder="Nhập số tài khoản"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="bank">Ngân hàng</Label>
                    <BankSelect
                      id="bank"
                      value={bank}
                      onChange={(val) => setBank(val)}
                      placeholder="Nhập tên ngân hàng"
                    />
                  </div>

                  {/* <label htmlFor="account-input" className="text-sm font-medium">
                  Số tioa
                </label>
                <input
                  id="account-input"
                  name="account"
                  placeholder="Enter your name"
                  type="text"
                  className="border rounded-md p-2 w-full"
                  required
                /> */}
                </div>
                <Button type="submit" className="w-full">
                  {isSubmitting ? 'Loading...' : 'Đăng nhập'}
                </Button>
                {/* <button
                type="submit"
                className="bg-blue-500 text-white py-2 px-4 rounded-md w-full disabled:bg-gray-300 disabled:text-gray-500"
              >
                {isLoggingIn ? 'Loading...' : 'Login'}
              </button> */}
              </fieldset>
            </form>
            {/* <div className="flex justify-center gap-4 mt-4">
              <Button variant="outline" size="icon" className="rounded-full">
                <Globe className="h-5 w-5" />
              </Button>
              <Button variant="outline" size="icon" className="rounded-full">
                <Moon className="h-5 w-5" />
              </Button>
            </div> */}
            {/* <div className="grid grid-cols-2 text-center text-sm text-gray-600 mt-6 gap-4">
              <div>
                <p>Logo</p>
                <p className="font-medium">VietQR Pay</p>
              </div>
              <div>
                <p>Logo</p>
                <p className="font-medium">VietQR Global</p>
              </div>
            </div> */}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
